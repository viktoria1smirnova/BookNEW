using System.Globalization;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using BookStoreCsvImport.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Чтобы русские буквы в HTML не превращались в коды вида &#x41C;
builder.Services.AddSingleton(HtmlEncoder.Create(UnicodeRanges.All));

// Singleton - чтобы список книг в памяти не пропадал между запросами
builder.Services.AddSingleton<IProductRepository, InMemoryProductRepository>();
builder.Services.AddSingleton<IProductImportService, ProductImportService>();

var russian = new CultureInfo("ru-RU");
CultureInfo.DefaultThreadCurrentCulture = russian;
CultureInfo.DefaultThreadCurrentUICulture = russian;

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Products/Error");
}

app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Products}/{action=Index}/{id?}");

app.Run();
