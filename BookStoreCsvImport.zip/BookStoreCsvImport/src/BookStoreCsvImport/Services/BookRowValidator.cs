using System.Globalization;
using BookStoreCsvImport.Models;

namespace BookStoreCsvImport.Services;

/// <summary>
/// Проверка одной строки CSV и создание из нее объекта Product.
/// Все ошибки строки собираются в список, чтобы пользователь увидел их сразу.
/// </summary>
public static class BookRowValidator
{
    // Индексы колонок (порядок задан в ImportSettings.Columns)
    private const int Sku = 0, Name = 1, Description = 2, Price = 3, Currency = 4, Category = 5,
        Stock = 6, ImageUrl = 7, IsActive = 8, Isbn = 9, Author = 10, Publisher = 11, Year = 12;

    /// <summary>
    /// Проверяет поля строки. Если ошибок нет - возвращает товар, иначе null.
    /// </summary>
    public static Product? ValidateRow(string[] f, List<string> errors)
    {
        var book = new Product
        {
            Sku = f[Sku],
            Name = f[Name],
            Description = f[Description],
            ImageUrl = f[ImageUrl],
            Author = f[Author],
            Publisher = f[Publisher],
            Currency = string.IsNullOrEmpty(f[Currency]) ? ImportSettings.DefaultCurrency : f[Currency].ToUpperInvariant(),
            CategoryName = string.IsNullOrEmpty(f[Category]) ? ImportSettings.DefaultCategory : f[Category]
        };

        if (book.Sku.Length == 0)
            errors.Add("Поле sku не может быть пустым");

        if (book.Name.Length == 0)
            errors.Add("Поле name не может быть пустым");

        if (TryParsePrice(f[Price], out decimal price) && price > 0)
            book.Price = price;
        else
            errors.Add("Цена должна быть числом больше нуля");

        if (int.TryParse(f[Stock], out int stock) && stock >= 0)
            book.StockQuantity = stock;
        else
            errors.Add("Остаток на складе не может быть отрицательным и должен быть целым числом");

        switch (f[IsActive].ToLowerInvariant())
        {
            case "true":
            case "1":
                book.IsActive = true;
                break;
            case "false":
            case "0":
                book.IsActive = false;
                break;
            default:
                errors.Add("Поле is_active должно быть true, false, 1 или 0");
                break;
        }

        string isbn = NormalizeIsbn(f[Isbn]);
        if (IsValidIsbn(isbn))
            book.Isbn = isbn;
        else
            errors.Add("ISBN должен содержать 10 или 13 символов");

        if (book.Author.Length == 0)
            errors.Add("Поле author (автор) обязательно");

        if (int.TryParse(f[Year], out int year)
            && year >= ImportSettings.MinPublicationYear
            && year <= ImportSettings.MaxPublicationYear)
            book.PublicationYear = year;
        else
            errors.Add($"Год издания должен быть от {ImportSettings.MinPublicationYear} до {ImportSettings.MaxPublicationYear}");

        return errors.Count == 0 ? book : null;
    }

    // Цена может быть записана с точкой или с запятой: 1290.50 или 1290,50
    private static bool TryParsePrice(string text, out decimal price)
    {
        return decimal.TryParse(text.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out price);
    }

    // Убираем дефисы и пробелы: 978-5-4461-0001-9 -> 9785446100019
    private static string NormalizeIsbn(string isbn)
    {
        return isbn.Replace("-", "").Replace(" ", "").ToUpperInvariant();
    }

    // ISBN-13 - только цифры; в ISBN-10 последним символом может быть X
    private static bool IsValidIsbn(string isbn)
    {
        if (isbn.Length == ImportSettings.IsbnLongLength)
            return isbn.All(char.IsDigit);

        if (isbn.Length == ImportSettings.IsbnShortLength)
            return isbn[..^1].All(char.IsDigit) && (char.IsDigit(isbn[^1]) || isbn[^1] == 'X');

        return false;
    }
}
