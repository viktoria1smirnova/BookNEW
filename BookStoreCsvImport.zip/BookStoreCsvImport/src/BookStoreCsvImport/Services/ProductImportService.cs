using System.Text;
using BookStoreCsvImport.Models;

namespace BookStoreCsvImport.Services;

/// <summary>
/// Сервис импорта книг из CSV: читает файл, проверяет строки
/// и добавляет корректные товары в репозиторий.
/// </summary>
public class ProductImportService : IProductImportService
{
    private readonly IProductRepository _repository;
    private readonly ILogger<ProductImportService>? _logger;

    public ProductImportService(IProductRepository repository, ILogger<ProductImportService>? logger = null)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _logger = logger;
    }

    public ImportResult ImportFromCsv(string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
        {
            var notFound = new ImportResult();
            notFound.AddError(ImportSettings.FileLevelRow, "Файл не найден: " + filePath);
            return notFound;
        }

        try
        {
            byte[] data = File.ReadAllBytes(filePath);
            return ImportText(DecodeBytes(data));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _logger?.LogError(ex, "Не удалось прочитать файл {Path}", filePath);
            var failed = new ImportResult();
            failed.AddError(ImportSettings.FileLevelRow, "Не удалось прочитать файл: " + ex.Message);
            return failed;
        }
    }

    public ImportResult ImportFromStream(Stream stream)
    {
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return ImportText(DecodeBytes(memory.ToArray()));
    }

    /// <summary>
    /// Переводит байты файла в текст. Если файл не в UTF-8,
    /// считаем, что он сохранен в Windows-1251 (так сохраняет Excel).
    /// </summary>
    private static string DecodeBytes(byte[] data)
    {
        try
        {
            var utf8 = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);
            return utf8.GetString(data).TrimStart('﻿');
        }
        catch (DecoderFallbackException)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return Encoding.GetEncoding(1251).GetString(data);
        }
    }

    /// <summary>
    /// Основной алгоритм: заголовок -> строки -> проверка -> добавление в память.
    /// </summary>
    private ImportResult ImportText(string text)
    {
        var result = new ImportResult();
        string[] lines = text.Replace("\r\n", "\n").Split('\n');

        if (lines.All(string.IsNullOrWhiteSpace))
        {
            result.AddError(ImportSettings.FileLevelRow, "Файл пуст. Данные для импорта отсутствуют");
            return result;
        }

        // Первая строка файла - заголовок
        char delimiter = CsvSplitter.GuessDelimiter(lines[0]);
        if (!IsHeaderCorrect(CsvSplitter.Split(lines[0], delimiter)))
        {
            result.AddError(1, "Неверный заголовок CSV. Ожидается: " + string.Join(",", ImportSettings.Columns));
            return result;
        }

        var skusInFile = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        for (int i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i]))
                continue;

            int rowNumber = i + 1; // нумерация строк как в Excel/Блокноте
            result.TotalRows++;

            string[] fields = CsvSplitter.Split(lines[i], delimiter);
            if (fields.Length != ImportSettings.Columns.Length)
            {
                result.AddError(rowNumber,
                    $"Неверное количество полей: {fields.Length} вместо {ImportSettings.Columns.Length}");
                continue;
            }

            var rowErrors = new List<string>();
            Product? book = BookRowValidator.ValidateRow(fields, rowErrors);
            if (book == null)
            {
                rowErrors.ForEach(e => result.AddError(rowNumber, e));
                continue;
            }

            // Дубликаты пропускаем (и в этом файле, и среди уже загруженных)
            if (skusInFile.Contains(book.Sku) || _repository.Exists(book.Sku))
            {
                result.AddError(rowNumber, $"Товар с артикулом {book.Sku} уже существует");
                continue;
            }

            _repository.Add(book);
            skusInFile.Add(book.Sku);
            result.ImportedCount++;
        }

        if (result.TotalRows == 0)
            result.AddError(ImportSettings.FileLevelRow, "Данные для импорта отсутствуют (есть только заголовок)");

        _logger?.LogInformation("Импорт завершен: строк {Total}, добавлено {Imported}, ошибок {Errors}",
            result.TotalRows, result.ImportedCount, result.ErrorCount);

        return result;
    }

    private static bool IsHeaderCorrect(string[] header)
    {
        if (header.Length != ImportSettings.Columns.Length)
            return false;

        for (int i = 0; i < header.Length; i++)
        {
            if (!string.Equals(header[i], ImportSettings.Columns[i], StringComparison.OrdinalIgnoreCase))
                return false;
        }

        return true;
    }
}
