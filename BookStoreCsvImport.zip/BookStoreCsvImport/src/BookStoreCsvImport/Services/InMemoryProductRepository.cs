using BookStoreCsvImport.Models;

namespace BookStoreCsvImport.Services;

/// <summary>
/// Хранилище товаров в памяти. Ключ словаря - артикул (sku),
/// поэтому поиск по артикулу работает быстро и не зависит от регистра.
/// </summary>
public class InMemoryProductRepository : IProductRepository
{
    private readonly Dictionary<string, Product> _products = new(StringComparer.OrdinalIgnoreCase);

    // Объект для блокировки: репозиторий один на все приложение (singleton),
    // а запросы могут приходить одновременно
    private readonly object _lock = new();

    public void Add(Product product)
    {
        ArgumentNullException.ThrowIfNull(product);

        lock (_lock)
        {
            _products[product.Sku.Trim()] = product;
        }
    }

    public IReadOnlyList<Product> GetAll()
    {
        lock (_lock)
        {
            return _products.Values.ToList();
        }
    }

    public Product? GetBySku(string sku)
    {
        if (string.IsNullOrWhiteSpace(sku))
            return null;

        lock (_lock)
        {
            return _products.TryGetValue(sku.Trim(), out var product) ? product : null;
        }
    }

    public bool Exists(string sku) => GetBySku(sku) != null;

    public void Clear()
    {
        lock (_lock)
        {
            _products.Clear();
        }
    }
}
