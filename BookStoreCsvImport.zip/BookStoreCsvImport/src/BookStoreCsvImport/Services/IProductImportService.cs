using BookStoreCsvImport.Models;

namespace BookStoreCsvImport.Services;

public interface IProductImportService
{
    /// <summary>Импорт из файла на диске.</summary>
    ImportResult ImportFromCsv(string filePath);

    /// <summary>Импорт из файла, загруженного через браузер.</summary>
    ImportResult ImportFromStream(Stream stream);
}
