using System.Text;

namespace BookStoreCsvImport.Services;

/// <summary>
/// Разбивает строку CSV на поля. Учитывает значения в кавычках,
/// внутри которых может стоять разделитель, и двойные кавычки "".
/// </summary>
public static class CsvSplitter
{
    /// <summary>
    /// Определяет разделитель по строке заголовка: точка с запятой или запятая.
    /// </summary>
    public static char GuessDelimiter(string headerLine)
    {
        int semicolons = headerLine.Count(c => c == ';');
        int commas = headerLine.Count(c => c == ',');
        return semicolons > commas ? ';' : ',';
    }

    public static string[] Split(string line, char delimiter = ',')
    {
        var result = new List<string>();
        var field = new StringBuilder();
        bool quoted = false;
        int pos = 0;

        while (pos < line.Length)
        {
            char ch = line[pos];

            if (quoted)
            {
                if (ch == '"' && pos + 1 < line.Length && line[pos + 1] == '"')
                {
                    field.Append('"');
                    pos++;
                }
                else if (ch == '"')
                {
                    quoted = false;
                }
                else
                {
                    field.Append(ch);
                }
            }
            else if (ch == '"')
            {
                quoted = true;
            }
            else if (ch == delimiter)
            {
                result.Add(field.ToString());
                field.Clear();
            }
            else
            {
                field.Append(ch);
            }

            pos++;
        }

        result.Add(field.ToString());
        return result.Select(f => f.Trim()).ToArray();
    }
}
