using BookStoreCsvImport.Models;

namespace BookStoreCsvImport.Services;

public interface IProductRepository
{
    void Add(Product product);
    IReadOnlyList<Product> GetAll();
    Product? GetBySku(string sku);
    bool Exists(string sku);
    void Clear();
}
