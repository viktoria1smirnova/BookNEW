using BookStoreCsvImport.Models;
using BookStoreCsvImport.Services;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreCsvImport.Controllers;

/// <summary>
/// Страницы каталога и импорта. Чтение и проверку CSV выполняет ProductImportService,
/// контроллер только принимает данные формы и передает результат в представление.
/// </summary>
public class ProductsController : Controller
{
    private readonly IProductRepository _repository;
    private readonly IProductImportService _importService;
    private readonly IWebHostEnvironment _env;

    public ProductsController(IProductRepository repository, IProductImportService importService, IWebHostEnvironment env)
    {
        _repository = repository;
        _importService = importService;
        _env = env;
    }

    // GET /Products - каталог с поиском, фильтром по категории и сортировкой
    public IActionResult Index(string? search, string? category, string? sort)
    {
        var all = _repository.GetAll();
        IEnumerable<Product> query = all;

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(p => p.Name.Contains(search, StringComparison.OrdinalIgnoreCase)
                                  || p.Author.Contains(search, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(category))
            query = query.Where(p => p.CategoryName == category);

        query = sort switch
        {
            "price_asc" => query.OrderBy(p => p.Price),
            "price_desc" => query.OrderByDescending(p => p.Price),
            "year_desc" => query.OrderByDescending(p => p.PublicationYear),
            _ => query.OrderBy(p => p.Name)
        };

        var model = new CatalogViewModel
        {
            Products = query.ToList(),
            Categories = all.Select(p => p.CategoryName).Distinct().OrderBy(c => c).ToList(),
            Search = search,
            Category = category,
            Sort = sort,
            TotalInMemory = all.Count
        };

        return View(model);
    }

    // GET /Products/Details/2001 - карточка книги
    public IActionResult Details(string id)
    {
        var book = _repository.GetBySku(id);
        return book == null ? NotFound() : View(book);
    }

    [HttpGet]
    public IActionResult Import()
    {
        return View(NewImportModel());
    }

    // POST /Products/Import - импорт по пути к файлу
    [HttpPost]
    [ActionName("Import")]
    [ValidateAntiForgeryToken]
    public IActionResult ImportPost(string? filePath)
    {
        var model = NewImportModel();
        model.FilePath = filePath ?? string.Empty;

        if (string.IsNullOrWhiteSpace(filePath))
        {
            model.Message = "Укажите путь к CSV-файлу";
            return View("Import", model);
        }

        model.FileName = Path.GetFileName(filePath);
        model.Result = _importService.ImportFromCsv(ResolvePath(filePath));
        return View("Import", model);
    }

    // POST /Products/Upload - импорт файла, выбранного в браузере
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Upload(IFormFile? csvFile)
    {
        var model = NewImportModel();

        if (csvFile == null || csvFile.Length == 0)
        {
            model.Message = "Выберите CSV-файл для загрузки";
            return View("Import", model);
        }

        if (!csvFile.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
        {
            model.Message = "Можно загрузить только файл с расширением .csv";
            return View("Import", model);
        }

        if (csvFile.Length > ImportSettings.MaxUploadBytes)
        {
            model.Message = "Файл слишком большой (максимум 2 МБ)";
            return View("Import", model);
        }

        using (var stream = csvFile.OpenReadStream())
        {
            model.Result = _importService.ImportFromStream(stream);
        }

        model.FileName = csvFile.FileName;
        return View("Import", model);
    }

    // POST /Products/Clear - очистить память (удобно для повторной демонстрации)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Clear()
    {
        _repository.Clear();
        TempData["Notice"] = "Список книг очищен";
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Error()
    {
        return View();
    }

    // Полный путь к файлу на диске используем как есть,
    // а путь вида /csv/books.csv ищем внутри папки wwwroot
    private string ResolvePath(string path)
    {
        path = path.Trim().Trim('"');
        if (Path.IsPathFullyQualified(path) && System.IO.File.Exists(path))
            return path;

        return Path.Combine(_env.WebRootPath, path.TrimStart('~', '/', '\\'));
    }

    // Список демонстрационных файлов из wwwroot/csv для быстрого выбора
    private ImportPageViewModel NewImportModel()
    {
        var model = new ImportPageViewModel();
        string csvDir = Path.Combine(_env.WebRootPath, "csv");

        if (Directory.Exists(csvDir))
        {
            model.DemoFiles = Directory.GetFiles(csvDir, "*.csv", SearchOption.AllDirectories)
                .Select(f => "/" + Path.GetRelativePath(_env.WebRootPath, f).Replace('\\', '/'))
                .OrderBy(f => f.Count(c => c == '/'))
                .ThenBy(f => f)
                .ToList();
        }

        return model;
    }
}
