namespace BookStoreCsvImport.Models;

/// <summary>
/// Итог импорта CSV-файла, который показывается на странице.
/// </summary>
public class ImportResult
{
    public int TotalRows { get; set; }
    public int ImportedCount { get; set; }
    public List<ImportError> Errors { get; set; } = new();

    public int ErrorCount => Errors.Count;

    public void AddError(int rowNumber, string message)
    {
        Errors.Add(new ImportError { RowNumber = rowNumber, Message = message });
    }
}
