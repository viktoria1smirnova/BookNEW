namespace BookStoreCsvImport.Models;

/// <summary>
/// Ошибка импорта: номер строки в файле и текст ошибки.
/// Номер 0 означает ошибку всего файла (а не конкретной строки).
/// </summary>
public class ImportError
{
    public int RowNumber { get; set; }
    public string Message { get; set; } = string.Empty;
}
