namespace BookStoreCsvImport.Models;

/// <summary>
/// Данные для страницы импорта: введенный путь, результат и сообщение.
/// </summary>
public class ImportPageViewModel
{
    public string FilePath { get; set; } = string.Empty;
    public string? FileName { get; set; }
    public string? Message { get; set; }
    public ImportResult? Result { get; set; }
    public List<string> DemoFiles { get; set; } = new();
}
