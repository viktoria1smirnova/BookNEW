namespace BookStoreCsvImport.Models;

/// <summary>
/// Константы импорта, чтобы не писать «магические» значения прямо в коде.
/// </summary>
public static class ImportSettings
{
    public const string DefaultCurrency = "RUB";
    public const string DefaultCategory = "Без категории";

    public const int MinPublicationYear = 1900;
    public const int IsbnShortLength = 10;
    public const int IsbnLongLength = 13;

    // Номер «строки» для ошибок, которые относятся ко всему файлу
    public const int FileLevelRow = 0;

    // Ограничение размера загружаемого файла - 2 МБ
    public const long MaxUploadBytes = 2 * 1024 * 1024;

    // Колонки CSV в том порядке, в котором они должны идти в файле
    public static readonly string[] Columns =
    {
        "sku", "name", "description", "price", "currency", "category_name", "stock",
        "image_url", "is_active", "isbn", "author", "publisher", "publication_year"
    };

    // Максимальный год издания - следующий год (книги могут выходить заранее)
    public static int MaxPublicationYear => DateTime.Today.Year + 1;
}
