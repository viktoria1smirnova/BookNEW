namespace BookStoreCsvImport.Models;

/// <summary>
/// Товар книжной лавки деканата (вариант 2 «Книги»).
/// </summary>
public class Product
{
    public string Sku { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string Currency { get; set; } = ImportSettings.DefaultCurrency;
    public string CategoryName { get; set; } = ImportSettings.DefaultCategory;
    public int StockQuantity { get; set; }
    public string ImageUrl { get; set; } = string.Empty;
    public bool IsActive { get; set; }

    // Дополнительные поля варианта «Книги»
    public string Isbn { get; set; } = string.Empty;
    public string Author { get; set; } = string.Empty;
    public string Publisher { get; set; } = string.Empty;
    public int PublicationYear { get; set; }
}
