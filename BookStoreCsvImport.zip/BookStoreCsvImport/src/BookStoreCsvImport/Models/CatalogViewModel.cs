namespace BookStoreCsvImport.Models;

/// <summary>
/// Данные для страницы каталога: отфильтрованные книги и параметры фильтра.
/// </summary>
public class CatalogViewModel
{
    public List<Product> Products { get; set; } = new();
    public List<string> Categories { get; set; } = new();

    public string? Search { get; set; }
    public string? Category { get; set; }
    public string? Sort { get; set; }

    public int TotalInMemory { get; set; }
    public int TotalStock => Products.Sum(p => p.StockQuantity);
    public decimal TotalValue => Products.Sum(p => p.Price * p.StockQuantity);
}
