using BookStoreCsvImport.Models;
using BookStoreCsvImport.Services;
using Xunit;

namespace BookStoreCsvImport.Tests;

public class RepositoryTests
{
    [Fact]
    public void Add_ThenGetAll_ReturnsAddedBook()
    {
        var repo = new InMemoryProductRepository();

        repo.Add(new Product { Sku = "2001", Name = "Основы C#" });

        Assert.Single(repo.GetAll());
    }

    [Fact]
    public void GetBySku_IgnoresCase()
    {
        var repo = new InMemoryProductRepository();
        repo.Add(new Product { Sku = "AB-10", Name = "Книга" });

        Assert.NotNull(repo.GetBySku("ab-10"));
        Assert.Null(repo.GetBySku("нет-такого"));
    }
}
