using BookStoreCsvImport.Services;
using Xunit;

namespace BookStoreCsvImport.Tests;

public class CsvSplitterTests
{
    [Fact]
    public void Split_SimpleLine()
    {
        var fields = CsvSplitter.Split("2001,Книга,,350");

        Assert.Equal(new[] { "2001", "Книга", "", "350" }, fields);
    }

    [Fact]
    public void Split_QuotedFieldWithComma()
    {
        var fields = CsvSplitter.Split("2006,\"Учебник для СПО, 3-е издание\",1690");

        Assert.Equal(3, fields.Length);
        Assert.Equal("Учебник для СПО, 3-е издание", fields[1]);
    }
}
