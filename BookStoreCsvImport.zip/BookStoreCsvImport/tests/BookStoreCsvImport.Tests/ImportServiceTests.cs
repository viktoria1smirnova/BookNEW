using System.Text;
using BookStoreCsvImport.Services;
using Xunit;

namespace BookStoreCsvImport.Tests;

public class ImportServiceTests
{
    private const string Header =
        "sku,name,description,price,currency,category_name,stock,image_url,is_active,isbn,author,publisher,publication_year";

    private const string GoodRow =
        "2001,Основы C#,Учебник,1890,RUB,Учебники,12,,true,9785446100019,Иванов И.И.,Питер,2023";

    private readonly InMemoryProductRepository _repo = new();

    private Models.ImportResult Import(params string[] lines)
    {
        var service = new ProductImportService(_repo);
        var bytes = Encoding.UTF8.GetBytes(string.Join("\n", lines));
        return service.ImportFromStream(new MemoryStream(bytes));
    }

    [Fact]
    public void ValidFile_AllRowsImported()
    {
        var result = Import(Header, GoodRow,
            "2002,Высшая математика,,1250,,,20,,1,9785001012344,Петрова А.С.,,2022");

        Assert.Equal(2, result.ImportedCount);
        Assert.Equal(0, result.ErrorCount);
        Assert.Equal("RUB", _repo.GetBySku("2002")!.Currency);
        Assert.Equal("Без категории", _repo.GetBySku("2002")!.CategoryName);
    }

    [Fact]
    public void EmptyFile_NoCrashAndError()
    {
        var result = Import("");

        Assert.Equal(0, result.ImportedCount);
        Assert.Equal(1, result.ErrorCount);
    }

    [Fact]
    public void NegativePrice_RowSkippedWithRowNumber()
    {
        var result = Import(Header,
            "2101,Теория вероятностей,,-500,RUB,Учебники,5,,true,9785446100019,Сидоров К.Л.,Питер,2022");

        Assert.Equal(0, result.ImportedCount);
        Assert.Equal(2, result.Errors[0].RowNumber);
        Assert.Equal("Цена должна быть числом больше нуля", result.Errors[0].Message);
    }

    [Fact]
    public void DuplicateSku_SecondRowSkipped()
    {
        var result = Import(Header, GoodRow, GoodRow);

        Assert.Equal(1, result.ImportedCount);
        Assert.Contains("уже существует", result.Errors[0].Message);
    }

    [Fact]
    public void NegativeStock_RowSkipped()
    {
        var result = Import(Header,
            "2301,Информатика,,990,RUB,Учебники,-5,,true,9785090023450,Белова Т.А.,Просвещение,2021");

        Assert.Equal(0, result.ImportedCount);
        Assert.Contains("не может быть отрицательным", result.Errors[0].Message);
    }

    [Fact]
    public void Windows1251File_CyrillicReadCorrectly()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var bytes = Encoding.GetEncoding(1251).GetBytes(Header + "\n" + GoodRow);

        var result = new ProductImportService(_repo).ImportFromStream(new MemoryStream(bytes));

        Assert.Equal(1, result.ImportedCount);
        Assert.Equal("Основы C#", _repo.GetBySku("2001")!.Name);
    }

    [Theory]
    [InlineData("yes", "Иванов И.И.")] // неверный is_active
    [InlineData("true", "")]           // нет автора
    public void WrongIsActiveOrEmptyAuthor_RowSkipped(string isActive, string author)
    {
        var result = Import(Header, $"2601,Право,,800,RUB,Учебники,2,,{isActive},9785940745679,{author},Юрайт,2023");

        Assert.Equal(0, result.ImportedCount);
        Assert.Equal(1, result.ErrorCount);
    }

    [Theory]
    [InlineData("97854461", "1999")]   // короткий ISBN
    [InlineData("9785446100019", "1850")] // год меньше 1900
    public void WrongIsbnOrYear_RowSkipped(string isbn, string year)
    {
        var result = Import(Header, $"2401,История,,1100,RUB,Учебники,3,,true,{isbn},Морозов А.Б.,Юрайт,{year}");

        Assert.Equal(0, result.ImportedCount);
        Assert.Equal(1, result.ErrorCount);
    }
}
